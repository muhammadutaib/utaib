import { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

export default function HeroSection() {
  const [nameVisible, setNameVisible] = useState(false);
  const [aliasText, setAliasText] = useState('');
  const [currentRole, setCurrentRole] = useState(0);

  const roles = [
    '50+ Plugins Engineered for Clients',
    'Scalable Systems for Any Server Size',
    'Minecraft Infrastructure Specialist',
    'Discord Automation Architect',
  ];

  useEffect(() => {
    setTimeout(() => setNameVisible(true), 500);
  }, []);

  useEffect(() => {
    if (!nameVisible) return;

    const fullText = 'Utab Phantom';
    let index = 0;

    const typeInterval = setInterval(() => {
      if (index <= fullText.length) {
        setAliasText(fullText.slice(0, index));
        index++;
      } else {
        clearInterval(typeInterval);
      }
    }, 100);

    return () => clearInterval(typeInterval);
  }, [nameVisible]);

  useEffect(() => {
    const roleInterval = setInterval(() => {
      setCurrentRole((prev) => (prev + 1) % roles.length);
    }, 3000);

    return () => clearInterval(roleInterval);
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center px-4">
      <div className="text-center z-10">
        <h1
          className={`text-5xl md:text-7xl font-bold mb-4 transition-all duration-1000 ${
            nameVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
          style={{
            background: 'linear-gradient(135deg, #00d4ff 0%, #0099ff 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            textShadow: '0 0 40px rgba(0, 212, 255, 0.5)',
          }}
        >
          Muhammad Utaib
        </h1>

        <div className="h-16 mb-8">
          <p
            className="text-3xl md:text-5xl font-light text-cyan-400"
            style={{
              textShadow: '0 0 20px rgba(0, 212, 255, 0.8)',
            }}
          >
            {aliasText}
            <span className="animate-pulse">|</span>
          </p>
        </div>

        <div className="h-20 flex items-center justify-center">
          {roles.map((role, index) => (
            <p
              key={index}
              className={`absolute text-lg md:text-xl text-blue-300 transition-all duration-700 ${
                currentRole === index
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-4'
              }`}
              style={{
                textShadow: '0 0 15px rgba(100, 200, 255, 0.6)',
              }}
            >
              {role}
            </p>
          ))}
        </div>
      </div>

      <div className="absolute bottom-10 animate-bounce">
        <ChevronDown className="w-8 h-8 text-cyan-400" />
      </div>
    </div>
  );
}
