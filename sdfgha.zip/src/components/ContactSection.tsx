import { Send, Github, MessageCircle, Mail } from 'lucide-react';

export default function ContactSection() {
  return (
    <div className="relative py-24 px-4">
      <div className="max-w-4xl mx-auto">
        <h2
          className="text-4xl md:text-5xl font-bold text-center mb-8 text-cyan-400"
          style={{
            textShadow: '0 0 30px rgba(0, 212, 255, 0.6)',
          }}
        >
          Let's Build Something Together
        </h2>

        <p className="text-center text-blue-300 mb-12 text-lg">
          Ready to scale your server infrastructure? Deploy custom systems? Automate
          your workflows?
        </p>

        <div
          className="relative p-8 md:p-12 rounded-lg backdrop-blur-md"
          style={{
            background:
              'linear-gradient(135deg, rgba(10, 22, 40, 0.8) 0%, rgba(0, 50, 80, 0.6) 100%)',
            border: '1px solid rgba(0, 212, 255, 0.3)',
            boxShadow: '0 8px 32px rgba(0, 212, 255, 0.2)',
          }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <a
              href="https://discord.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative p-6 rounded-lg bg-gradient-to-br from-blue-950/40 to-cyan-950/20 border border-cyan-500/30 backdrop-blur-sm transition-all duration-300 hover:border-cyan-400 hover:scale-105"
              style={{
                boxShadow: '0 0 20px rgba(0, 212, 255, 0.1)',
              }}
            >
              <div
                className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background:
                    'linear-gradient(135deg, rgba(0, 212, 255, 0.1) 0%, rgba(0, 153, 255, 0.1) 100%)',
                }}
              />

              <div className="relative z-10 flex items-center">
                <MessageCircle
                  className="w-8 h-8 text-cyan-400 mr-4"
                  style={{
                    filter: 'drop-shadow(0 0 10px rgba(0, 212, 255, 0.6))',
                  }}
                />
                <div>
                  <h3 className="text-xl font-semibold text-blue-100 mb-1">
                    Discord
                  </h3>
                  <p className="text-sm text-blue-300/80">@utabphantom</p>
                </div>
              </div>
            </a>

            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative p-6 rounded-lg bg-gradient-to-br from-blue-950/40 to-cyan-950/20 border border-cyan-500/30 backdrop-blur-sm transition-all duration-300 hover:border-cyan-400 hover:scale-105"
              style={{
                boxShadow: '0 0 20px rgba(0, 212, 255, 0.1)',
              }}
            >
              <div
                className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background:
                    'linear-gradient(135deg, rgba(0, 212, 255, 0.1) 0%, rgba(0, 153, 255, 0.1) 100%)',
                }}
              />

              <div className="relative z-10 flex items-center">
                <Github
                  className="w-8 h-8 text-cyan-400 mr-4"
                  style={{
                    filter: 'drop-shadow(0 0 10px rgba(0, 212, 255, 0.6))',
                  }}
                />
                <div>
                  <h3 className="text-xl font-semibold text-blue-100 mb-1">GitHub</h3>
                  <p className="text-sm text-blue-300/80">View Repositories</p>
                </div>
              </div>
            </a>

            <a
              href="mailto:contact@utabphantom.dev"
              className="group relative p-6 rounded-lg bg-gradient-to-br from-blue-950/40 to-cyan-950/20 border border-cyan-500/30 backdrop-blur-sm transition-all duration-300 hover:border-cyan-400 hover:scale-105"
              style={{
                boxShadow: '0 0 20px rgba(0, 212, 255, 0.1)',
              }}
            >
              <div
                className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background:
                    'linear-gradient(135deg, rgba(0, 212, 255, 0.1) 0%, rgba(0, 153, 255, 0.1) 100%)',
                }}
              />

              <div className="relative z-10 flex items-center">
                <Mail
                  className="w-8 h-8 text-cyan-400 mr-4"
                  style={{
                    filter: 'drop-shadow(0 0 10px rgba(0, 212, 255, 0.6))',
                  }}
                />
                <div>
                  <h3 className="text-xl font-semibold text-blue-100 mb-1">Email</h3>
                  <p className="text-sm text-blue-300/80">Direct Communication</p>
                </div>
              </div>
            </a>

            <div
              className="group relative p-6 rounded-lg bg-gradient-to-br from-cyan-950/40 to-blue-950/20 border border-cyan-400/50 backdrop-blur-sm"
              style={{
                boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)',
              }}
            >
              <div className="relative z-10 flex items-center">
                <Send
                  className="w-8 h-8 text-cyan-300 mr-4"
                  style={{
                    filter: 'drop-shadow(0 0 15px rgba(0, 212, 255, 0.8))',
                  }}
                />
                <div>
                  <h3 className="text-xl font-semibold text-cyan-300 mb-1">
                    Commission Open
                  </h3>
                  <p className="text-sm text-blue-200">
                    Available for custom projects
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center">
            <p className="text-blue-300/80 text-sm">
              Server Networks • Custom Plugins • Bot Development • Infrastructure
              Design
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
