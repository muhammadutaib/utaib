import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Server Owner - Phoenix Network',
    role: 'Network Director',
    content:
      'Utab delivered a custom economy system that handles 10k+ concurrent players flawlessly. Performance is incredible and the code quality is exceptional.',
    rating: 5,
  },
  {
    name: 'Development Team - Aether SMP',
    role: 'Lead Developer',
    content:
      'Working with Utab was seamless. The faction plugin exceeded our expectations and integrated perfectly with our existing systems.',
    rating: 5,
  },
  {
    name: 'Community Manager - Skyreach',
    role: 'Operations Lead',
    content:
      'The Discord-Minecraft bridge transformed our community engagement. Real-time sync works perfectly and support was outstanding.',
    rating: 5,
  },
  {
    name: 'Owner - Crimson Realms',
    role: 'Server Administrator',
    content:
      'Professional, efficient, and reliable. Utab built our entire skyblock infrastructure from scratch and continues to provide excellent support.',
    rating: 5,
  },
];

export default function TestimonialsSection() {
  return (
    <div className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <h2
          className="text-4xl md:text-5xl font-bold text-center mb-16 text-cyan-400"
          style={{
            textShadow: '0 0 30px rgba(0, 212, 255, 0.6)',
          }}
        >
          Client Transmissions
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="relative p-6 rounded-lg backdrop-blur-md transition-all duration-300 hover:scale-105"
              style={{
                background:
                  'linear-gradient(135deg, rgba(10, 22, 40, 0.7) 0%, rgba(0, 50, 80, 0.5) 100%)',
                border: '1px solid rgba(0, 212, 255, 0.2)',
                boxShadow: '0 8px 32px rgba(0, 212, 255, 0.1)',
              }}
            >
              <Quote
                className="absolute top-4 right-4 w-8 h-8 text-cyan-400/20"
                style={{
                  filter: 'drop-shadow(0 0 10px rgba(0, 212, 255, 0.3))',
                }}
              />

              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-cyan-400 fill-cyan-400"
                    style={{
                      filter: 'drop-shadow(0 0 5px rgba(0, 212, 255, 0.6))',
                    }}
                  />
                ))}
              </div>

              <p className="text-blue-100 mb-4 leading-relaxed">
                {testimonial.content}
              </p>

              <div className="border-t border-cyan-500/20 pt-4">
                <p className="font-semibold text-cyan-300">{testimonial.name}</p>
                <p className="text-sm text-blue-300/60">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
