import { useState } from 'react';
import { Folder, Star, Users, Zap } from 'lucide-react';

const categories = ['All', 'SMP Plugins', 'Core Frameworks', 'Automation', 'Commissioned'];

const projects = [
  {
    title: 'Advanced Economy System',
    category: 'SMP Plugins',
    description: 'Multi-currency economy with shops, auctions, and banking infrastructure',
    features: ['Player Shops', 'Dynamic Pricing', 'Transaction History', 'Bank Accounts'],
    scale: '10k+ Players',
  },
  {
    title: 'Custom Faction Framework',
    category: 'Core Frameworks',
    description: 'Complete faction system with wars, claims, and diplomatic relations',
    features: ['Territory Control', 'War System', 'Alliances', 'Power Management'],
    scale: '50+ Servers',
  },
  {
    title: 'Discord-Server Bridge',
    category: 'Automation',
    description: 'Real-time sync between Discord and Minecraft with role management',
    features: ['Chat Sync', 'Role Mirroring', 'Event Notifications', 'Command Bridge'],
    scale: '100k+ Users',
  },
  {
    title: 'Skyblock Core',
    category: 'SMP Plugins',
    description: 'Complete skyblock infrastructure with islands, challenges, and progression',
    features: ['Island Management', 'Challenge System', 'Leaderboards', 'Co-op Islands'],
    scale: '5k+ Islands',
  },
  {
    title: 'Anti-Cheat System',
    category: 'Core Frameworks',
    description: 'Advanced detection system for movement, combat, and interaction exploits',
    features: ['ML Detection', 'Auto-Ban', 'Admin Alerts', 'Replay System'],
    scale: '99.7% Accuracy',
  },
  {
    title: 'Server Analytics Bot',
    category: 'Automation',
    description: 'Discord bot tracking server metrics, player stats, and performance data',
    features: ['Real-time Stats', 'Custom Graphs', 'Alerts', 'Report Generation'],
    scale: '24/7 Monitoring',
  },
];

export default function ProjectsSection() {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredProjects =
    activeCategory === 'All'
      ? projects
      : projects.filter((p) => p.category === activeCategory);

  return (
    <div className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <h2
          className="text-4xl md:text-5xl font-bold text-center mb-8 text-cyan-400"
          style={{
            textShadow: '0 0 30px rgba(0, 212, 255, 0.6)',
          }}
        >
          Project Archive
        </h2>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 rounded-full border transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                  : 'bg-blue-950/30 border-cyan-500/20 text-blue-300 hover:border-cyan-400/50'
              }`}
              style={{
                boxShadow:
                  activeCategory === category
                    ? '0 0 20px rgba(0, 212, 255, 0.4)'
                    : 'none',
              }}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project, index) => (
            <div
              key={index}
              className="group relative p-6 rounded-lg bg-gradient-to-br from-blue-950/40 to-cyan-950/20 border border-cyan-500/20 backdrop-blur-sm transition-all duration-300 hover:border-cyan-400/60 hover:scale-105"
              style={{
                boxShadow: '0 0 20px rgba(0, 212, 255, 0.1)',
              }}
            >
              <div
                className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background:
                    'linear-gradient(135deg, rgba(0, 212, 255, 0.1) 0%, rgba(0, 153, 255, 0.1) 100%)',
                }}
              />

              <div className="relative z-10">
                <div className="flex items-start justify-between mb-4">
                  <Folder className="w-8 h-8 text-cyan-400" />
                  <span className="text-xs text-cyan-300 bg-cyan-500/20 px-2 py-1 rounded">
                    {project.category}
                  </span>
                </div>

                <h3 className="text-xl font-bold mb-2 text-blue-100">
                  {project.title}
                </h3>
                <p className="text-sm text-blue-300/80 mb-4">
                  {project.description}
                </p>

                <div className="space-y-2 mb-4">
                  {project.features.map((feature, i) => (
                    <div key={i} className="flex items-center text-xs text-blue-300">
                      <Star className="w-3 h-3 mr-2 text-cyan-400" />
                      {feature}
                    </div>
                  ))}
                </div>

                <div className="flex items-center text-xs text-cyan-400 font-semibold">
                  <Zap className="w-4 h-4 mr-1" />
                  {project.scale}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
