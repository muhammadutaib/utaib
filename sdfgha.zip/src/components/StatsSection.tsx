import { useState, useEffect, useRef } from 'react';

interface Stat {
  label: string;
  value: number;
  suffix: string;
}

const stats: Stat[] = [
  { label: 'Plugins Delivered', value: 50, suffix: '+' },
  { label: 'Server Networks Supported', value: 100, suffix: 'k+' },
  { label: 'Years of Engineering', value: 5, suffix: '+' },
  { label: 'System Uptime', value: 99, suffix: '.9%' },
];

export default function StatsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div ref={sectionRef} className="relative py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <StatCounter
              key={index}
              {...stat}
              isVisible={isVisible}
              delay={index * 100}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCounter({
  label,
  value,
  suffix,
  isVisible,
  delay,
}: Stat & { isVisible: boolean; delay: number }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isVisible) return;

    const timeout = setTimeout(() => {
      const duration = 2000;
      const steps = 60;
      const increment = value / steps;
      let current = 0;

      const interval = setInterval(() => {
        current += increment;
        if (current >= value) {
          setCount(value);
          clearInterval(interval);
        } else {
          setCount(Math.floor(current));
        }
      }, duration / steps);

      return () => clearInterval(interval);
    }, delay);

    return () => clearTimeout(timeout);
  }, [isVisible, value, delay]);

  return (
    <div
      className="relative p-6 rounded-lg bg-gradient-to-br from-blue-950/30 to-cyan-950/20 border border-cyan-500/20 backdrop-blur-sm transform transition-all duration-500 hover:scale-105 hover:border-cyan-400/50"
      style={{
        boxShadow: '0 0 20px rgba(0, 212, 255, 0.1)',
      }}
    >
      <div className="text-center">
        <div
          className="text-4xl md:text-5xl font-bold mb-2 text-cyan-400"
          style={{
            textShadow: '0 0 20px rgba(0, 212, 255, 0.8)',
          }}
        >
          {count}
          {suffix}
        </div>
        <div className="text-sm md:text-base text-blue-300">{label}</div>
      </div>
    </div>
  );
}
