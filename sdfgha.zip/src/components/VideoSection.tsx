import { useState } from 'react';
import { ChevronLeft, ChevronRight, Play } from 'lucide-react';

const videos = [
  {
    id: 'dQw4w9WgXcQ',
    title: 'Economy System Demo',
    description: 'Full walkthrough of multi-currency economy plugin',
  },
  {
    id: 'dQw4w9WgXcQ',
    title: 'Faction Wars Gameplay',
    description: 'Real-time faction combat and territory control',
  },
  {
    id: 'dQw4w9WgXcQ',
    title: 'Discord Bot Integration',
    description: 'Seamless server-discord communication system',
  },
  {
    id: 'dQw4w9WgXcQ',
    title: 'Skyblock Core Features',
    description: 'Island management and challenge progression',
  },
];

export default function VideoSection() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextVideo = () => {
    setCurrentIndex((prev) => (prev + 1) % videos.length);
  };

  const prevVideo = () => {
    setCurrentIndex((prev) => (prev - 1 + videos.length) % videos.length);
  };

  return (
    <div className="relative py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <h2
          className="text-4xl md:text-5xl font-bold text-center mb-16 text-cyan-400"
          style={{
            textShadow: '0 0 30px rgba(0, 212, 255, 0.6)',
          }}
        >
          Systems in Action
        </h2>

        <div className="relative">
          <div className="relative aspect-video rounded-lg overflow-hidden border border-cyan-500/30 backdrop-blur-sm bg-black/50">
            <iframe
              src={`https://www.youtube.com/embed/${videos[currentIndex].id}`}
              title={videos[currentIndex].title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          </div>

          <button
            onClick={prevVideo}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 p-3 rounded-full bg-cyan-500/20 border border-cyan-400/50 text-cyan-400 hover:bg-cyan-500/30 transition-all duration-300"
            style={{
              boxShadow: '0 0 20px rgba(0, 212, 255, 0.3)',
            }}
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={nextVideo}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 p-3 rounded-full bg-cyan-500/20 border border-cyan-400/50 text-cyan-400 hover:bg-cyan-500/30 transition-all duration-300"
            style={{
              boxShadow: '0 0 20px rgba(0, 212, 255, 0.3)',
            }}
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="mt-6 text-center">
            <h3 className="text-xl font-semibold text-blue-100 mb-2">
              {videos[currentIndex].title}
            </h3>
            <p className="text-blue-300/80">{videos[currentIndex].description}</p>
          </div>

          <div className="flex justify-center gap-2 mt-6">
            {videos.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentIndex
                    ? 'bg-cyan-400 w-8'
                    : 'bg-cyan-500/30 hover:bg-cyan-500/50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
