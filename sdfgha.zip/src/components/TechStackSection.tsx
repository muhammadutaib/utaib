import { useState, useEffect } from 'react';

const technologies = [
  { name: 'Java', category: 'Core' },
  { name: 'Spigot', category: 'Framework' },
  { name: 'Paper', category: 'Framework' },
  { name: 'Bukkit', category: 'Framework' },
  { name: 'Node.js', category: 'Backend' },
  { name: 'Discord.js', category: 'Automation' },
  { name: 'MySQL', category: 'Database' },
  { name: 'MongoDB', category: 'Database' },
  { name: 'Redis', category: 'Cache' },
  { name: 'Docker', category: 'DevOps' },
  { name: 'Git', category: 'Version Control' },
  { name: 'Maven', category: 'Build Tool' },
];

export default function TechStackSection() {
  const [pulseIndex, setPulseIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setPulseIndex((prev) => (prev + 1) % technologies.length);
    }, 300);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <h2
          className="text-4xl md:text-5xl font-bold text-center mb-16 text-cyan-400"
          style={{
            textShadow: '0 0 30px rgba(0, 212, 255, 0.6)',
          }}
        >
          Technology Arsenal
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {technologies.map((tech, index) => (
            <div
              key={index}
              className={`relative p-6 rounded-lg bg-gradient-to-br from-blue-950/40 to-cyan-950/20 border backdrop-blur-sm transition-all duration-300 ${
                pulseIndex === index
                  ? 'border-cyan-400 scale-105'
                  : 'border-cyan-500/20'
              }`}
              style={{
                boxShadow:
                  pulseIndex === index
                    ? '0 0 30px rgba(0, 212, 255, 0.4)'
                    : '0 0 10px rgba(0, 212, 255, 0.1)',
              }}
            >
              <div className="text-center">
                <div
                  className={`text-xl font-bold mb-1 transition-all duration-300 ${
                    pulseIndex === index ? 'text-cyan-300' : 'text-cyan-400'
                  }`}
                  style={{
                    textShadow:
                      pulseIndex === index
                        ? '0 0 20px rgba(0, 212, 255, 1)'
                        : '0 0 10px rgba(0, 212, 255, 0.6)',
                  }}
                >
                  {tech.name}
                </div>
                <div className="text-xs text-blue-300/60">{tech.category}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
