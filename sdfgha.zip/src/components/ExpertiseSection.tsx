import { Code2, Server, Zap, Database, Bot, Shield } from 'lucide-react';

const expertise = [
  {
    icon: Code2,
    title: 'Java Development',
    description: 'Expert-level Java engineering with focus on performance-critical server systems',
  },
  {
    icon: Server,
    title: 'Paper/Spigot Architecture',
    description: 'Deep knowledge of Minecraft server internals and plugin API optimization',
  },
  {
    icon: Zap,
    title: 'Custom Plugin Systems',
    description: 'Scalable, modular plugin frameworks built for production environments',
  },
  {
    icon: Database,
    title: 'Performance Optimization',
    description: 'Memory management, tick optimization, and resource efficiency at scale',
  },
  {
    icon: Bot,
    title: 'Discord Automation',
    description: 'Advanced bot systems with server integration and workflow automation',
  },
  {
    icon: Shield,
    title: 'Server Infrastructure',
    description: 'Full-stack server design from architecture to deployment and monitoring',
  },
];

export default function ExpertiseSection() {
  return (
    <div className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <h2
          className="text-4xl md:text-5xl font-bold text-center mb-16 text-cyan-400"
          style={{
            textShadow: '0 0 30px rgba(0, 212, 255, 0.6)',
          }}
        >
          Core Expertise
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {expertise.map((item, index) => (
            <div
              key={index}
              className="group relative p-6 rounded-lg bg-gradient-to-br from-blue-950/40 to-cyan-950/20 border border-cyan-500/20 backdrop-blur-sm transition-all duration-300 hover:border-cyan-400/60 hover:scale-105"
              style={{
                boxShadow: '0 0 20px rgba(0, 212, 255, 0.1)',
              }}
            >
              <div
                className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background:
                    'linear-gradient(135deg, rgba(0, 212, 255, 0.1) 0%, rgba(0, 153, 255, 0.1) 100%)',
                  boxShadow: '0 0 40px rgba(0, 212, 255, 0.3)',
                }}
              />

              <div className="relative z-10">
                <item.icon
                  className="w-12 h-12 mb-4 text-cyan-400 group-hover:text-cyan-300 transition-colors"
                  style={{
                    filter: 'drop-shadow(0 0 10px rgba(0, 212, 255, 0.8))',
                  }}
                />
                <h3 className="text-xl font-semibold mb-2 text-blue-100">
                  {item.title}
                </h3>
                <p className="text-blue-300/80 text-sm">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
