import { useEffect, useState } from 'react';
import SpaceBackground from './components/SpaceBackground';
import HeroSection from './components/HeroSection';
import StatsSection from './components/StatsSection';
import ExpertiseSection from './components/ExpertiseSection';
import TechStackSection from './components/TechStackSection';
import ProjectsSection from './components/ProjectsSection';
import VideoSection from './components/VideoSection';
import TestimonialsSection from './components/TestimonialsSection';
import ContactSection from './components/ContactSection';
import { Menu, X } from 'lucide-react';

function App() {
  const [scrollY, setScrollY] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMenuOpen(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-black text-white overflow-x-hidden">
      <SpaceBackground />

      <div
        className="fixed top-0 left-0 right-0 z-40 transition-all duration-300"
        style={{
          background:
            scrollY > 100
              ? 'rgba(10, 22, 40, 0.9)'
              : 'transparent',
          backdropFilter: scrollY > 100 ? 'blur(10px)' : 'none',
          borderBottom:
            scrollY > 100 ? '1px solid rgba(0, 212, 255, 0.2)' : 'none',
        }}
      >
        <nav className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div
            className="text-xl font-bold text-cyan-400"
            style={{
              textShadow: '0 0 20px rgba(0, 212, 255, 0.8)',
            }}
          >
            Utab Phantom
          </div>

          <button
            className="md:hidden text-cyan-400"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <div className="hidden md:flex gap-6">
            {['expertise', 'projects', 'showcase', 'contact'].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className="text-blue-300 hover:text-cyan-400 transition-colors capitalize"
              >
                {section}
              </button>
            ))}
          </div>
        </nav>

        {menuOpen && (
          <div className="md:hidden bg-gradient-to-b from-blue-950/95 to-cyan-950/95 backdrop-blur-lg border-b border-cyan-500/20">
            <div className="flex flex-col px-4 py-4 space-y-4">
              {['expertise', 'projects', 'showcase', 'contact'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className="text-blue-300 hover:text-cyan-400 transition-colors capitalize text-left"
                >
                  {section}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div
        className="relative z-10"
        style={{
          transform: `translateY(${scrollY * 0.5}px)`,
        }}
      >
        <HeroSection />
      </div>

      <div className="relative z-20">
        <StatsSection />

        <div id="expertise">
          <ExpertiseSection />
        </div>

        <TechStackSection />

        <div id="projects">
          <ProjectsSection />
        </div>

        <div id="showcase">
          <VideoSection />
        </div>

        <TestimonialsSection />

        <div id="contact">
          <ContactSection />
        </div>

        <footer className="relative py-8 px-4 border-t border-cyan-500/20">
          <div className="max-w-7xl mx-auto text-center">
            <p className="text-blue-300/60 text-sm">
              Muhammad Utaib (Utab Phantom) • Systems Engineer • 2026
            </p>
            <p className="text-blue-300/40 text-xs mt-2">
              Powering Digital Worlds Through Code
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
